﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnInterfaces
{
    interface IX
    {
        void M1();
    }
  interface IX1 : IX
    {

    }
    interface IX2:IX
    {

    }
    class Demo4
    {
    }
}
