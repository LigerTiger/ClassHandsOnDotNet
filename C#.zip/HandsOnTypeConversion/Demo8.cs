﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnTypeConversion
{
    class Demo8
    {
      
        static void Main()
        {
            int productId = 32324;
            string productName = "Mouse";
            Console.WriteLine("ID: " + productId + " " + "ProductName: " + productName);
            Console.Read();
          
        }
    }
}
