﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnTypeConversion
{
    class Demo5
    {
        static void Main()
        {
            int i = 100;
            string s = "ABCD";
            object empId = 1000;
            object empName = "ROhan";
            object salary = 12.35;
            object gender = 'M';
            object isProjectAssigned = false;

        }
    }
}
