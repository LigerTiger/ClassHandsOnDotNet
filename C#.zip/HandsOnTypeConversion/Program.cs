﻿using System;

namespace HandsOnTypeConversion
{
    class Program
    {
        static void Main(string[] args)
        {
            //direct conversion
            byte b = 100;
            byte b1 = b;
            int k = 3232;
            int k1 = k;
        }
    }
}
