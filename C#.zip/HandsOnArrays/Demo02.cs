﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3.HandsOnArrays
{
    class Demo02
    {
        static void Main()
        {
            double[] d = new double[3] { 12.3, 34.5, 56.7};
            char[] ch = { 'a', 'b', '3' };
            bool[] result = { true, false, true, false };
            object[] items = { 12, 23.3, "Abin", true }; //store mixed values
        }
    }
}
