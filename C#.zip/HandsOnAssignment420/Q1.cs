﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnAssignment420
{
    class Q1
    {
        //Write a program in C# to display a message as follows: “Welcome to the world of C#”
        static void Main()
        {
            Console.WriteLine("Welcome to the world of C#");
        }
    }
}
