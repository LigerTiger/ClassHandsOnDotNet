﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace HandsOnNonGenericCollections
{
    class Demo
    {
        static void Main()
        {
            ArrayList l1 = new ArrayList() { "Rose", "Lilly", "Jasmine", "Tulips" }; //collection initialier
            l1.Add("MariGold");
        }
    }
}
