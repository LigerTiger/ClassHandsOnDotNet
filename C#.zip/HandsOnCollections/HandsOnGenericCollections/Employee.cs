﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOnGenericCollections
{
    internal class Employee
    {
        public int eid;
        public string name;
        static void Main()
        {
            Employee employee = new Employee();
            Employee employee1 = new Employee();
            Employee employee2 = new Employee();
        }
    }
   
}
