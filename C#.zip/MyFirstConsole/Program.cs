﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstConsole
{
    class Program
    {
        static void Main(string[] args) //Entry point of the execution
        {
            Console.WriteLine("Welcome to World of C#");
            Console.ReadKey(); //reads output until user press any key
        }
    }
}
